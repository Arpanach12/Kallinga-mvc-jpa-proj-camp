package com.mindtree.adminusermvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminusermvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
