package com.mindtree.adminusermvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminusermvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminusermvcApplication.class, args);
	}

}
