package com.mindtree.classmanagementmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassmanagementmvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassmanagementmvcApplication.class, args);
	}

}
